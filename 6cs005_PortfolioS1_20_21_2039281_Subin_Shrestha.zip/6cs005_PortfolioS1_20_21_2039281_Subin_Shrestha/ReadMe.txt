6cs005_High_Performance_computing Sem1 2019/2020
Instruction for portfolio's files submission

1. Copy and paste your code using C files follow the names given for each file
2. Copy and paste the journal word file and name it as 6cs005_LearningJournal_Sem1_19_20_StudentID

Name : Subin Shrestha
ID : 2039281 
6CS006

All the Required files are in the current folder.
Instruction to compile and run each file is at the top of each files.


Output folder has text files of Outputs as well as output image from Gaussian Blur. 

Supporting files folder contains all the necessary files that i used to answers the questions in the portfolio.

GitHub Link:
    https://github.com/sthasubin429/cuda-cw


I used google colab to compute cuda files.
Colab Notebook Link:
    https://colab.research.google.com/drive/1z33UO5jvMT-euyKz958rY2K7cvjMzt4m?usp=sharing